alert('va estudar nene');
<button onclick="alert('Pom')" class="tecla tecla_pom">Pom</button>